# IT110-Grocery > 2025-02-13 1:23am
https://universe.roboflow.com/wave-zpavv/it110-grocery

Provided by a Roboflow user
License: CC BY 4.0

